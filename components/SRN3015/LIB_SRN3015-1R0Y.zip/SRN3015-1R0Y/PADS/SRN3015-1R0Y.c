*PADS-LIBRARY-SCH-DECALS-V9*

SRN3015-1R0Y     32000 32000 100 10 100 10 4 4 0 2 24
TIMESTAMP 2018.01.18.07.53.35
"Default Font"
"Default Font"
650   250   0 8 100 10 "Default Font"
REF-DES
650   150   0 8 100 10 "Default Font"
PART-TYPE
400   -50   0 12 100 10 "Default Font"
*
400   -150  0 12 100 10 "Default Font"
*
OPEN   2 10 0 -1
200   0     1777 -1754 200   -52   300   48   
300   0    
OPEN   2 10 0 -1
300   0     1777 -1754 300   -52   400   48   
400   0    
OPEN   2 10 0 -1
400   0     1777 -1754 400   -52   500   48   
500   0    
OPEN   2 10 0 -1
500   0     1777 -1754 500   -52   600   48   
600   0    
T0     0     0 0 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T800   0     0 2 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0

*END*
