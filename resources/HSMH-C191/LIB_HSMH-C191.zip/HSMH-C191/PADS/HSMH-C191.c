*PADS-LIBRARY-SCH-DECALS-V9*

HSMH-C191              32000 32000 100 10 100 10 4 8 0 2 0
TIMESTAMP 2018.01.29.15.06.24
"Default Font"
"Default Font"
500   350   0 0 100 10 "Default Font"
REF-DES
500   250   0 0 100 10 "Default Font"
PART-TYPE
500   -200  0 0 100 10 "Default Font"
*
500   -300  0 0 100 10 "Default Font"
*
CLOSED 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   100  
200   -100 
OPEN   2 10 0 -1
260   120  
160   220  
COPCLS 4 10 0 -1
220   190  
190   160  
160   220  
220   190  
OPEN   2 10 0 -1
340   120  
240   220  
COPCLS 4 10 0 -1
300   190  
270   160  
240   220  
300   190  
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
400   0    
500   0    
T0     0     0 0 60    10    0 2 10    -10   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 60    10    0 2 10    -10   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*
